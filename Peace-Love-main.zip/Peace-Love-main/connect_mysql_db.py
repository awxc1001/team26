import sqlite3
import mysql.connector

# Connect to the SQLite database
sqlite_conn = sqlite3.connect('BankingAdvisorData.db')
sqlite_cursor = sqlite_conn.cursor()

# Connect to the MySQL database
mysql_conn = mysql.connector.connect(
    host='localhost',
    user='user1',
    password='user1',
    database='BankingAdvisorData'
)

mysql_cursor = mysql_conn.cursor()

# Get the list of tables from SQLite
sqlite_cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = sqlite_cursor.fetchall()

for table_name in tables:
    table_name = table_name[0]

    # Get the CREATE TABLE statement from SQLite
    sqlite_cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}';")
    create_table_sql = sqlite_cursor.fetchone()[0]

    # Replace SQLite-specific syntax with MySQL-compatible syntax
    create_table_sql = create_table_sql.replace("AUTOINCREMENT", "AUTO_INCREMENT")

    # Add length specification for BLOB/TEXT columns used in key specifications
    create_table_sql = create_table_sql.replace("TEXT", "VARCHAR(20)")

    # Create the table in MySQL
    mysql_cursor.execute(f"DROP TABLE IF EXISTS {table_name};")
    mysql_cursor.execute(create_table_sql)

    # Modify the column length if necessary
    if 'client_info' in create_table_sql:
        mysql_cursor.execute(f"ALTER TABLE {table_name} MODIFY client_info VARCHAR(3000);")

    if 'esg_summary' in create_table_sql:
        mysql_cursor.execute(f"ALTER TABLE {table_name} MODIFY esg_summary VARCHAR(3000);")

    if 'product_update' in create_table_sql:
        mysql_cursor.execute(f"ALTER TABLE {table_name} MODIFY product_update VARCHAR(3000);")

    if 'event_update' in create_table_sql:
        mysql_cursor.execute(f"ALTER TABLE {table_name} MODIFY event_update VARCHAR(3000);")

    if 'product_info' in create_table_sql:
        mysql_cursor.execute(f"ALTER TABLE {table_name} MODIFY product_info VARCHAR(3000);")

    if 'event_info' in create_table_sql:
        mysql_cursor.execute(f"ALTER TABLE {table_name} MODIFY event_info VARCHAR(3000);")

    # Get the data from the SQLite table
    sqlite_cursor.execute(f"SELECT * FROM {table_name};")
    rows = sqlite_cursor.fetchall()

    # Get the column names from the SQLite table
    column_names = [description[0] for description in sqlite_cursor.description]
    columns = ", ".join(column_names)
    placeholders = ", ".join(["%s"] * len(column_names))

    # Insert the data into the MySQL table
    insert_sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
    mysql_cursor.executemany(insert_sql, rows)
    mysql_conn.commit()

# Close the database connections
sqlite_conn.close()
mysql_conn.close()