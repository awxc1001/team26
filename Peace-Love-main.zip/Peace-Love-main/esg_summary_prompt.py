def outcome_prompt(client_info):
    sample_output = '''{
        "client_id": "C001",
        "environmental": {
            "overall_rating": "Moderate",
            "carbon_footprint": "High",
            "energy_efficiency": "High",
            "waste_management": "High",
            "water_usage": "Good",
            "sustainable_practices": "Low",
            "pollution_and_emissions": "Good",
            "biodiversity": "Good"
            "comment": "No specific improvement areas identified."
        },
        "social": {
            "overall_rating": "Good",
            "employee_welfare": "Good",
            "diversity_and_inclusion": "Good",
            "community_engagement": "Low",
            "human_rights": "Low",
            "customer_satisfaction": "Low",
            "labor_standards": "Good",
            "health_and_safety": "Low",
            "comment": "Identified areas for improvement: community engagement - 50% female representation on the board."

        },
        "governance": {
            "overall_rating": "Good",
            "board_composition": "Good",
            "executive_compensation": "Sustainability",
            "transparency": "Good",
            "ethical_practices": "Low",
            "shareholder_rights": "Low",
            "regulatory_compliance": "Low",
            "risk_management": "Low",
            "comment": "Identified areas for improvement: board_composition - 15% female representation on the board."

        }
    }'''

    prompt = f"""
    You will be given a Commonwealth Bank - Business Bank customer's ESG data.
    Your task is to analyse the customer's ESG data. For each attribute in each category, provide an approximate rating for the attribute based on the attribute's description, then provide an approximate rating for each category.
    You will provide comment on the customer's each ESG category and the areas for improvement if there is any attribute under "Low" rating.

    The output should be in JSON format, including the client id and all the estimated ratings according to sample output.

    Sample output is provided between <sample_output_start> and <sample_output_end>.
    <sample_output_start>
    {sample_output}
    <sample_output_end>

    Additional Guidelines:
    1. Do not provide any explanation or rationale on the generated ratings.
    2. Do not respond with anything apart from the JSON.
    3. Make sure the generated ratings for ESG categories and their attributes are strictly "Low" or "Good" or "High", but the "carbon_footprint" attribute strictly take "Low" or "Moderate" or "High" as its rating, and "executive_compensation" should be "Sustainability", "Company" or "Project".
    4. Make sure the generated ratings are consistent with the attribute descriptions.
    5. If there is "High", "Excellent", "Comprehensive", "Actively", "Fully", "Strong" or "Strict" keywords within the attribute description, then the single attribute's rating should just be "High".
    7. If there is "Good", "Robust" or "Adheres" keywords within the attribute description, then the single attribute's rating should just be "Good".
    8. If "board_composition" is less than 30%, the rating for this attribute should be "Low". If it's more than 40%, then the single attribute's rating should be "High". Else if it's between and include 30% to 40%, the single attribute's rating should be "Good".
    9. When providing comment for each ESG category, if there is no specific improvement areas identified, the comment should be "No specific improvement areas identified.".
    10. When providing comment for each ESG category, if there is any specific attribute tagged "Low" as its rating, the comment should be "Identified areas for improvement: <attribute name> - <original attribute description>". If multiple attributes are tagged "Low", the comment should be "Identified areas for improvement: <attribute name> - <original attribute description>, <attribute name> - <original attribute description>".
    11. When providing the overall rating for each ESG category, please analyse the number of "High", "Good", "Moderate" and "Low" ratings for each attribute within the category to determine the overall rating. 
    12. If there is exactly one "Low" attribute rating within its category, for example, only "board_composition" is "Low" in Governance category, the overall rating for Governance category must be "Good"
    13. If there is area of improvement, then the overall rating is "Good" for that category. Unless if there are more than three "Low" ratings in a category, the overall rating for this category should be "Low".
    14. Client_id must be exactly the same as the input client_id.
    15. If "carbon_footprint" attribute description has "Low", then this is not a "Low" rating since it has a low carbon emission. Vice versa, if the "carbon_footprint" is "High", then this is an area of improvement that needs to be mentioned in the comment.
    
    Based on the customer's ESG data, please provide an approximate rating for each attribute within each ESG category: environmental, social and governance, based on the attribute's description text.
    Then, please provide an approximate rating for each category: environmental, social and governance. 
    Customer data is provided between <customer_data_start> and <customer_data_end>.
    <customer_data_start>
    {client_info}
    <customer_data_end>
    """
    return prompt

