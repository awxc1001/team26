def products_prompt(products, financial_data, call_report):
    sample_output = '''
    {
        "product_1": "<product_and_rationale1>",
        "product_2": "<product_and_rationale2>"
    }
    '''

    prompt = f"""
    You are an expert adviser at the Commonwealth Bank of Australia.
    You will be given financial data and a call report about a client, as well as a list of products the bank has to offer.
    Your task is to recommend 2 products that are suitable for the client given their financial needs and call history.

    Please make sure you read through each of the provided data carefully, you should:
    1. Read through the list of products, making sure you understand what each product offers, its eligibility and benefits.
    2. Read through the client's financial data to understand their financial standing and potential needs.
    3. Read through the call report to understand what the client is interested in.

    The output should be in JSON format, including the two products according to sample output format.
    Do not provide any unnecessary spaces and line breaks.

    Sample output is provided between <sample_output_start> and <sample_output_end>.
    <sample_output_start>
    {sample_output}
    <sample_output_end>

    Additional Guidelines:
    1. The 2 products you recommend should be the 2 most relevant products to the client from the list of products.
    2. Product recommendation should be based strongly on the client's financial needs or their call history, ideally both.
    3. In your response, <product_and_rationale> should follow the structure "You can recommend the <product_name> product to this client since <rationale>" as if you are talking to the actual banking adviser responsible for this client.
    4. Check that you have referenced the product's name exactly as it is provided in the product data.
    5. If you are referencing a call in your response, instead of saying "as discussed in their call report", state the date the client called the bank on.
    6. Do not respond with anything apart from the json response. Must not contains unnecessary spaces and line breaks.
    7. <product_and_rationale> should be complete sentences with no linebreaks in between.

    The list of products is provided between <products_start> and <products_end>.
    <products_start>
    {products}
    <products_end>

    The client's financial data is provided between <financial_data_start> and <financial_data_end>.
    <financial_data_start>
    {financial_data}
    <financial_data_end>

    The client's call report is provided between <call_report_start> and <call_report_end>.
    <call_report_start>
    {call_report}
    <call_report_end>

    Please use the provided list of products, client financial data, and client call report to come up with 2 recommended products.
    """

    return prompt