import sqlite3
import json
import os

conn = sqlite3.connect("BankingAdvisorData.db")
cursor = conn.cursor()

# Create client table
cursor.execute("""
CREATE TABLE IF NOT EXISTS clients (
   client_id TEXT PRIMARY KEY,
   client_info TEXT,
   esg_summary TEXT,
   product_update TEXT,
   event_update TEXT
)
""")

# Create product table
cursor.execute("""
CREATE TABLE IF NOT EXISTS products (
   product_id TEXT PRIMARY KEY,
   product_info TEXT
)
""")

# Create news table
cursor.execute("""
CREATE TABLE IF NOT EXISTS events (
   event_id TEXT PRIMARY KEY,
   event_info TEXT
)
""")

conn.commit()

# Insert client data
clients_folder = "Desktop/BankingAdvisor_DataSet/Clients"
for filename in os.listdir(clients_folder):
    if filename.endswith(".json"):
        with open(os.path.join(clients_folder, filename), "r") as file:
            client_data = json.load(file)
            client_id = client_data["client_profile"]["client_id"]
            client_info_str = json.dumps(client_data)

            cursor.execute(
                "INSERT OR REPLACE INTO clients (client_id, client_info) VALUES (?, ?)",
                (client_id, client_info_str)
            )

# Insert products data
with open("Desktop/BankingAdvisor_DataSet/products.json", "r") as file:
    products = json.load(file)["products"]
    for product in products:
        product_id = product["product_id"]
        product_info_str = json.dumps(product)

        cursor.execute(
            "INSERT OR REPLACE INTO products (product_id, product_info) VALUES (?, ?)",
            (product_id, product_info_str)
        )

# Insert news data
with open("Desktop/BankingAdvisor_DataSet/CurrentEvents.json", "r") as file:
    current_events = json.load(file)["current_events"]
    for event in current_events:
        event_id = event["event_id"]
        event_info_str = json.dumps(event)

        cursor.execute(
            "INSERT OR REPLACE INTO events (event_id, event_info) VALUES (?, ?)",
            (event_id, event_info_str)
        )

conn.commit()
conn.close()
