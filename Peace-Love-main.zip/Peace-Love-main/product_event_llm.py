from openai import OpenAI, DefaultHttpxClient
import os
import json
import sqlite3
import time

import product_prompt
import event_prompt

api_base = "https://genai-llm-gw.anigenailabs01.aws.prod.au.internal.cba"  # litellm server

client = OpenAI(
    base_url=api_base,
    api_key=" API key",
)

clients_selected = "Desktop/BankingAdvisor_DataSet/Clients/C010.json"
products = "Desktop/BankingAdvisor_DataSet/Products.json"
events = "Desktop/BankingAdvisor_DataSet/CurrentEvents.json"

with open(clients_selected, "r") as file:
    client_data = json.load(file)

with open(products, "r") as file:
    product_data = json.load(file)

with open(events, "r") as file:
    event_data = json.load(file)

client_id = client_data["client_profile"]["client_id"]

client_info_str = json.dumps(client_data)

product_content = product_prompt.products_prompt(product_data["products"], client_data["financial_data"], client_data["call_report"])  # Replace this with the function that generates the prompt
event_content = event_prompt.events_prompt(event_data["current_events"], client_data["client_profile"]["business_area"], client_data["client_profile"]["address"], client_data["call_report"])  # Replace this with the function that generates the prompt

# Change the model parameter to call gpt-4o,bedrock-claude-sonnet,bedrock-claude-haiku etc
product_response = client.chat.completions.create(
    model="gpt-4o_v2024-05-13",  # Replace this with model from the current catalogue e.g gpt-3.5-turbo,gpt-4o,bedrock-claude-sonnet,bedrock-claude-haiku,mistral-instruct7b,mixtral-8x7b-instruct,mixtral-large
    messages=[{"role": "user", "content": product_content}],
    stream=True,
)

event_response = client.chat.completions.create(
    model="gpt-4o_v2024-05-13",  # Replace this with model from the current catalogue e.g gpt-3.5-turbo,gpt-4o,bedrock-claude-sonnet,bedrock-claude-haiku,mistral-instruct7b,mixtral-8x7b-instruct,mixtral-large
    messages=[{"role": "user", "content": event_content}],
    stream=True,
)

def transform_response_to_str(llm_output):
    response_content = ""
    for chunk in llm_output:
        response_content += chunk.choices[0].delta.content or ""
    try:
        response_json = json.loads(response_content)
        response_str = json.dumps(response_json, indent=1)
    except Exception as e:
        print(f"Error occured, please retry: {e}")
        response_str = None
    return response_str

product_update = transform_response_to_str(product_response)
event_update = transform_response_to_str(event_response)


conn = sqlite3.connect("BankingAdvisorData.db")
cursor = conn.cursor()

cursor.execute(
    "UPDATE clients SET product_update = ? WHERE client_id = ?",
    (product_update, client_id)
)

cursor.execute(
    "UPDATE clients SET event_update = ? WHERE client_id = ?",
    (event_update, client_id)
)

conn.commit()
conn.close()